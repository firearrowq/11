# Telegram werewolf bot

## Rules

English version working in process.

[Chinese](/README.zh-CN.md)

## Dependencies

* Node.js
* MongoDB

## Deploy

```shell
git clone https://github.com/ProphetVillage/telegram-werewolf-bot.git
cd telegram-werewolf-bot
npm i
cp config.example.js config.js
vi config.js
node werewolf.js
```
