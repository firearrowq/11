'use strict';

const ba = require('./ba');
const db = require('./database');

ba.start();
